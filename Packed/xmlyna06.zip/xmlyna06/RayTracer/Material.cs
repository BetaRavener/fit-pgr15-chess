﻿namespace RayTracer
{
    internal class Material
    {
    }
}