namespace Chess.Scene.State
{
    public enum GameState
    {
        NotStarted,
        Running,
        Ended
    }
}