namespace Chess.Scene
{
    public enum FigureType
    {
        Unknown,
        King,
        Rook,
        Bishop,
        Queen,
        Knight,
        Pawn
    }
}